package pl.clearday.app;

import android.app.*;
import android.os.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.content.*;
import android.view.*;
import android.widget.*;
import java.text.*;
import java.util.*;

public class MainActivity extends Activity {
    final int BG=Color.rgb(3,12,8), CARD=Color.rgb(9,28,20), CARD2=Color.rgb(13,39,28);
    final int GREEN=Color.rgb(69,232,120), TEXT=Color.WHITE, MUTED=Color.rgb(157,177,166);
    LinearLayout root, content, nav;
    android.content.SharedPreferences sp;
    long start;
    int perDay=10, pack=20, goal=90;
    float price=12f;
    ArrayList<String> diary=new ArrayList<>();

    int dp(float n){return (int)(n*getResources().getDisplayMetrics().density+.5f);}
    TextView tv(String s,float size,int color,boolean bold){
        TextView t=new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color);
        t.setGravity(Gravity.CENTER_VERTICAL); t.setPadding(dp(4),0,dp(4),0);
        if(bold)t.setTypeface(android.graphics.Typeface.DEFAULT,1); return t;
    }
    LinearLayout box(int pad){
        LinearLayout l=new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); l.setPadding(dp(pad),dp(pad),dp(pad),dp(pad));
        GradientDrawable g=new GradientDrawable();g.setColor(CARD);g.setCornerRadius(dp(20));l.setBackground(g);
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.setMargins(dp(12),dp(7),dp(12),dp(7));l.setLayoutParams(p);return l;
    }
    Button button(String s, View.OnClickListener c){
        Button b=new Button(this);b.setText(s);b.setTextColor(BG);b.setTextSize(14);b.setAllCaps(false);b.setOnClickListener(c);
        GradientDrawable g=new GradientDrawable();g.setColor(GREEN);g.setCornerRadius(dp(18));b.setBackground(g);
        b.setPadding(dp(10),0,dp(10),0);b.setMinHeight(dp(48));return b;
    }
    @Override public void onCreate(Bundle b){super.onCreate(b);sp=getSharedPreferences("clearday",0);load();build();showHome();}
    void load(){
        start=sp.getLong("start",System.currentTimeMillis());perDay=sp.getInt("perDay",10);pack=sp.getInt("pack",20);price=sp.getFloat("price",12);goal=sp.getInt("goal",90);
        String d=sp.getString("diary",""); if(!d.isEmpty()) diary.addAll(Arrays.asList(d.split("\\n",-1)));
    }
    void save(){sp.edit().putLong("start",start).putInt("perDay",perDay).putInt("pack",pack).putFloat("price",price).putInt("goal",goal).putString("diary",joinDiary()).apply();}
    String joinDiary(){StringBuilder b=new StringBuilder();for(String s:diary){if(b.length()>0)b.append("\\n");b.append(s);}return b.toString();}
    long days(){return Math.max(0,(System.currentTimeMillis()-start)/86400000L);}
    double saved(){return days()*((double)price*perDay/pack);}
    long notSmoked(){return days()*perDay;}
    void build(){
        root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setBackgroundColor(BG);
        content=new LinearLayout(this);content.setOrientation(LinearLayout.VERTICAL);content.setPadding(0,dp(8),0,0);
        ScrollView scroll=new ScrollView(this);scroll.setFillViewport(true);scroll.addView(content);
        root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        nav=new LinearLayout(this);nav.setGravity(Gravity.CENTER);nav.setPadding(0,dp(5),0,dp(5));nav.setBackgroundColor(Color.rgb(3,16,11));
        String[] names={"⌂\\nStart","▥\\nStatystyki","▤\\nDziennik","♕\\nOsiągnięcia","☰\\nWięcej"};
        for(int i=0;i<5;i++){final int x=i;TextView n=tv(names[i],11,MUTED,true);n.setGravity(Gravity.CENTER);nav.addView(n,new LinearLayout.LayoutParams(0,dp(58),1));n.setOnClickListener(v->{if(x==0)showHome();if(x==1)showStats();if(x==2)showDiary();if(x==3)showAchievements();if(x==4)showMore();});}
        root.addView(nav,new LinearLayout.LayoutParams(-1,dp(68)));setContentView(root);
    }
    void clear(){content.removeAllViews();}
    void header(String title, boolean back){
        LinearLayout h=new LinearLayout(this);h.setGravity(Gravity.CENTER_VERTICAL);h.setPadding(dp(18),dp(4),dp(18),0);
        if(back){TextView b=tv("‹",36,TEXT,false);h.addView(b,new LinearLayout.LayoutParams(dp(42),dp(55)));b.setOnClickListener(v->showMore());}
        TextView t=tv(title,27,TEXT,true);h.addView(t,new LinearLayout.LayoutParams(0,dp(55),1));
        content.addView(h);
    }
    void showHome(){
        clear(); LinearLayout top=new LinearLayout(this);top.setPadding(dp(20),0,dp(20),0);top.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout a=new LinearLayout(this);a.setOrientation(LinearLayout.VERTICAL);a.setLayoutParams(new LinearLayout.LayoutParams(0,dp(72),1));
        a.addView(tv("Siemanko 👋",28,TEXT,true));a.addView(tv("Dbasz o siebie, trzymaj tak! 💪",14,MUTED,false));
        top.addView(a);TextView gear=tv("⚙",28,TEXT,false);top.addView(gear,new LinearLayout.LayoutParams(dp(50),dp(60)));gear.setOnClickListener(v->settings());
        content.addView(top);
        LinearLayout card=box(14); content.addView(card);
        QuitRing ring=new QuitRing(this);card.addView(ring,new LinearLayout.LayoutParams(-1,dp(315)));
        LinearLayout stats=new LinearLayout(this);String money=String.format(Locale.US,"€%.2f",saved());
        smallStat(stats,money,"Zaoszczędzone");smallStat(stats,""+notSmoked(),"Nie wypalone");smallStat(stats,""+days(),"Twoja seria");card.addView(stats);
        Button proud=button("Jestem dumny z siebie! 💪",v->toast("Każdy dzień bez papierosa ma znaczenie. 💚"));card.addView(proud,new LinearLayout.LayoutParams(-1,dp(54)));
        TextView craving=tv("🔥  Mam ochotę zapalić",16,GREEN,true);craving.setGravity(Gravity.CENTER);card.addView(craving,new LinearLayout.LayoutParams(-1,dp(65)));craving.setOnClickListener(v->craving());
    }
    void smallStat(LinearLayout row,String a,String b){
        LinearLayout x=new LinearLayout(this);x.setOrientation(LinearLayout.VERTICAL);x.setGravity(Gravity.CENTER);x.setPadding(dp(3),0,dp(3),0);
        x.addView(tv(a,19,GREEN,true));TextView q=tv(b,11,MUTED,false);q.setGravity(Gravity.CENTER);x.addView(q);
        row.addView(x,new LinearLayout.LayoutParams(0,dp(70),1));
    }
    class QuitRing extends View{
        Paint p=new Paint(1);QuitRing(Context c){super(c);}
        protected void onDraw(Canvas c){super.onDraw(c);float cx=getWidth()/2f,cy=dp(145),r=dp(105);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(dp(14));p.setColor(Color.rgb(18,58,40));c.drawCircle(cx,cy,r,p);p.setColor(GREEN);c.drawArc(cx-r,cy-r,cx+r,cy+r,-90,(float)Math.min(360,days()*360d/goal),false,p);p.setStyle(Paint.Style.FILL);p.setTextAlign(Paint.Align.CENTER);p.setTypeface(Typeface.DEFAULT_BOLD);p.setTextSize(dp(16));p.setColor(TEXT);c.drawText("Nie palisz już od",cx,cy-dp(30),p);p.setTextSize(dp(55));c.drawText(""+days(),cx,cy+dp(30),p);p.setTextSize(dp(17));c.drawText("dni",cx,cy+dp(57),p);p.setTextSize(dp(14));p.setTypeface(Typeface.DEFAULT);c.drawText((hours()+" godz.   "+minutes()+" min.   "+seconds()+" sek."),cx,cy+dp(93),p);p.setTextSize(dp(12));p.setColor(MUTED);c.drawText("„Lepsze życie zaczyna się od jednej decyzji.”",cx,cy+dp(126),p);}
    }
    long hours(){return ((System.currentTimeMillis()-start)/3600000)%24;} long minutes(){return ((System.currentTimeMillis()-start)/60000)%60;} long seconds(){return ((System.currentTimeMillis()-start)/1000)%60;}
    void showStats(){
        clear();header("Statystyki",false);
        LinearLayout f=box(10);LinearLayout sw=new LinearLayout(this);String[] q={"Tydzień","Miesiąc","Rok"};for(String s:q){TextView z=tv(s,13,TEXT,true);z.setGravity(Gravity.CENTER);sw.addView(z,new LinearLayout.LayoutParams(0,dp(42),1));}f.addView(sw);content.addView(f);
        LinearLayout cards=new LinearLayout(this);smallStat(cards,String.format(Locale.US,"€%.2f",saved()),"Zaoszczędzone");smallStat(cards,""+notSmoked(),"Nie wypalone");content.addView(cards);
        LinearLayout chart=box(14);chart.addView(tv("Zaoszczędzone pieniądze",18,TEXT,true));chart.addView(new Bars(this),new LinearLayout.LayoutParams(-1,dp(230)));content.addView(chart);
        LinearLayout prog=box(14);prog.addView(tv("Postęp w czasie",18,TEXT,true));prog.addView(tv("Dni bez palenia: "+days()+" / "+goal,14,MUTED,false));content.addView(prog);
    }
    class Bars extends View{Paint p=new Paint(1);Bars(Context c){super(c);}protected void onDraw(Canvas c){int w=getWidth(),h=getHeight();p.setColor(Color.rgb(18,57,40));for(int i=0;i<30;i++){float x=8+i*(w-16)/30f;float bh=20+(i%9)*17;c.drawRoundRect(x,h-bh,x+dp(7),h,5,5,p);}p.setColor(GREEN);for(int i=0;i<30;i++){float x=8+i*(w-16)/30f;float bh=12+(i%8)*19;c.drawRoundRect(x,h-bh,x+dp(7),h,5,5,p);}}}
    void showDiary(){
        clear();header("Dziennik",false);Button add=button("+ Dodaj wpis",v->addDiary());content.addView(add,new LinearLayout.LayoutParams(-1,dp(52)));
        if(diary.isEmpty()){LinearLayout e=box(18);e.addView(tv("Twój dziennik jest pusty.",18,TEXT,true));e.addView(tv("Zapisuj samopoczucie, głód nikotynowy i sukcesy.",14,MUTED,false));content.addView(e);}
        for(String s:diary){LinearLayout e=box(12);e.addView(tv("😊   "+s,15,TEXT,true));e.addView(tv("Wpis zapisany w ClearDay",12,MUTED,false));content.addView(e);}
    }
    void addDiary(){
        final EditText e=new EditText(this);e.setHint("Jak się dziś czujesz?");e.setTextColor(TEXT);e.setHintTextColor(MUTED);
        new AlertDialog.Builder(this).setTitle("Dodaj wpis").setView(e).setPositiveButton("Zapisz",(d,w)->{if(e.length()>0){diary.add(0,e.getText().toString());save();showDiary();}}).setNegativeButton("Anuluj",null).show();
    }
    void showAchievements(){
        clear();header("Osiągnięcia",false);String[] n={"1 dzień","7 dni","30 dni","€50","Lepszy sen","90 dni","Więcej czasu","Silniejszy umysł"};long d=days();
        for(int i=0;i<n.length;i++){boolean ok=(i==0&&d>=1)||(i==1&&d>=7)||(i==2&&d>=30)||(i==3&&saved()>=50)||(i==5&&d>=90);
            LinearLayout e=box(10);LinearLayout r=new LinearLayout(this);TextView ico=tv(ok?"✓":"◇",34,ok?GREEN:MUTED,true);r.addView(ico,new LinearLayout.LayoutParams(dp(58),dp(65)));LinearLayout z=new LinearLayout(this);z.setOrientation(LinearLayout.VERTICAL);z.addView(tv(n[i],16,TEXT,true));z.addView(tv(ok?"Odblokowane":"Zablokowane",12,ok?GREEN:MUTED,false));r.addView(z);e.addView(r);content.addView(e);}
    }
    void showMore(){
        clear();header("Więcej",false);
        content.addView(menu("📅  Kalendarz","Zobacz dni bez palenia",v->calendar()));
        content.addView(menu("🔥  Mam ochotę zapalić","Szybkie sposoby na przetrwanie głodu",v->craving()));
        content.addView(menu("⚙  Ustawienia","Cena paczki, papierosy, data startu",v->settings()));
        content.addView(menu("🎯  Cele","Twój cel i mniejsze kamienie milowe",v->goals()));
        content.addView(menu("🌿  O aplikacji","ClearDay 2.0",v->toast("ClearDay — dzień po dniu. 💚")));
    }
    LinearLayout menu(String a,String b,View.OnClickListener l){LinearLayout e=box(10);e.setOnClickListener(l);e.addView(tv(a,17,TEXT,true));e.addView(tv(b,13,MUTED,false));return e;}
    void calendar(){
        clear();header("Kalendarz",true);Calendar now=Calendar.getInstance();int month=now.get(Calendar.MONTH),year=now.get(Calendar.YEAR);
        TextView title=tv(new SimpleDateFormat("LLLL yyyy",new Locale("pl","PL")).format(now.getTime()),20,TEXT,true);title.setGravity(Gravity.CENTER);content.addView(title);
        GridLayout g=new GridLayout(this);g.setColumnCount(7);String[] wd={"Pn","Wt","Śr","Cz","Pt","So","Nd"};for(String s:wd){TextView x=tv(s,12,MUTED,true);x.setGravity(Gravity.CENTER);g.addView(x,new ViewGroup.LayoutParams(dp(45),dp(35)));}
        Calendar first=new GregorianCalendar(year,month,1);int offset=(first.get(Calendar.DAY_OF_WEEK)+5)%7;for(int i=0;i<offset;i++)g.addView(new TextView(this),new ViewGroup.LayoutParams(dp(45),dp(45)));
        int max=now.getActualMaximum(Calendar.DAY_OF_MONTH);for(int day=1;day<=max;day++){final int dd=day;TextView x=tv(""+day,13,TEXT,true);x.setGravity(Gravity.CENTER);Calendar date=new GregorianCalendar(year,month,day);boolean quit=date.getTimeInMillis()>=start && date.getTimeInMillis()<=System.currentTimeMillis();if(quit){GradientDrawable bg=new GradientDrawable();bg.setColor(Color.rgb(40,150,77));bg.setShape(GradientDrawable.OVAL);x.setBackground(bg);}g.addView(x,new ViewGroup.LayoutParams(dp(45),dp(45)));}content.addView(g);
        content.addView(menu("Ten miesiąc","Dni bez palenia: "+days()+"   •   Zaoszczędzone: "+String.format(Locale.US,"€%.2f",saved()),v->{}));
    }
    void settings(){
        LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);l.setPadding(dp(20),0,dp(20),0);
        EditText priceE=input("Cena paczki (€)",String.valueOf(price));EditText dayE=input("Papierosy dziennie",String.valueOf(perDay));EditText packE=input("Papierosów w paczce",String.valueOf(pack));
        l.addView(priceE);l.addView(dayE);l.addView(packE);Button reset=button("Ustaw datę rzucenia na TERAZ",v->{start=System.currentTimeMillis();save();showHome();});l.addView(reset);
        new AlertDialog.Builder(this).setTitle("Ustawienia").setView(l).setPositiveButton("Zapisz",(d,w)->{try{price=Float.parseFloat(priceE.getText().toString());perDay=Integer.parseInt(dayE.getText().toString());pack=Integer.parseInt(packE.getText().toString());}catch(Exception ignored){}save();showHome();}).setNegativeButton("Anuluj",null).show();
    }
    EditText input(String hint,String val){EditText e=new EditText(this);e.setHint(hint);e.setText(val);e.setTextColor(TEXT);e.setHintTextColor(MUTED);e.setInputType(2|8192);e.setPadding(0,dp(8),0,dp(8));return e;}
    void goals(){
        clear();header("Cele",true);LinearLayout e=box(14);e.addView(tv("🎯  Twój główny cel",18,TEXT,true));e.addView(tv(days()+" / "+goal+" dni",16,GREEN,true));ProgressBar p=new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal);p.setMax(goal);p.setProgress((int)Math.min(goal,days()));e.addView(p,new LinearLayout.LayoutParams(-1,dp(15)));content.addView(e);
        content.addView(menu("☑  7 dni bez palenia",days()>=7?"Ukończone":"Jeszcze "+Math.max(0,7-days())+" dni",v->{}));
        content.addView(menu("☐  30 dni bez palenia",days()>=30?"Ukończone":"Jeszcze "+Math.max(0,30-days())+" dni",v->{}));
        Button b=button("Zmień cel",v->goalDialog());content.addView(b,new LinearLayout.LayoutParams(-1,dp(52)));
    }
    void goalDialog(){EditText e=input("Cel w dniach",""+goal);new AlertDialog.Builder(this).setTitle("Ustaw cel").setView(e).setPositiveButton("Zapisz",(d,w)->{try{goal=Integer.parseInt(e.getText().toString());}catch(Exception ignored){}save();goals();}).setNegativeButton("Anuluj",null).show();}
    void craving(){
        String[] tips={"Ćwiczenie oddechowe","Szybki trening — 5 minut","Wypij szklankę wody","Przypomnij sobie, po co rzucasz","Napisz w dzienniku"};
        new AlertDialog.Builder(this).setTitle("Mam ochotę zapalić").setMessage("To tylko chwilowa ochota. Wybierz coś na najbliższe kilka minut.").setItems(tips,(d,w)->toast(tips[w]+" 💚")).setNegativeButton("Zamknij",null).show();
    }
    void toast(String s){Toast.makeText(this,s,Toast.LENGTH_SHORT).show();}
}
