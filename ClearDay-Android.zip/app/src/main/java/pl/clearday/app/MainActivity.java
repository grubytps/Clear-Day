package pl.clearday.app;

import android.app.*;
import android.os.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.view.*;
import android.content.*;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity {
    private AppView v;
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        v = new AppView(this);
        setContentView(v);
    }

    class AppView extends View {
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        long start;
        float packPrice = 12f;
        int perDay = 10;
        int cigarettesPerPack = 20;
        int tab = 0;
        ArrayList<String> diary = new ArrayList<>();

        int bg = Color.rgb(3,10,8);
        int panel = Color.rgb(9,27,20);
        int green = Color.rgb(62,235,116);
        int muted = Color.rgb(158,177,166);

        AppView(Context c) {
            super(c);
            getData();
            setLayerType(View.LAYER_TYPE_SOFTWARE, null);
        }

        void getData() {
            android.content.SharedPreferences s = getSharedPreferences("data",0);
            start = s.getLong("start", System.currentTimeMillis());
            packPrice = s.getFloat("price", 12f);
            perDay = s.getInt("perDay", 10);
            cigarettesPerPack = s.getInt("pack", 20);
        }

        long days() { return Math.max(0,(System.currentTimeMillis()-start)/86400000L); }
        long hours() { return Math.max(0,(System.currentTimeMillis()-start)/3600000L)%24; }
        long minutes() { return Math.max(0,(System.currentTimeMillis()-start)/60000L)%60; }
        long seconds() { return Math.max(0,(System.currentTimeMillis()-start)/1000L)%60; }

        void text(Canvas c,String s,float x,float y,float size,int color,boolean bold) {
            p.setStyle(Paint.Style.FILL);
            p.setColor(color); p.setTextSize(size);
            p.setTypeface(Typeface.create("sans",bold?Typeface.BOLD:Typeface.NORMAL));
            c.drawText(s,x,y,p);
        }
        void center(Canvas c,String s,float x,float y,float size,int color,boolean bold) {
            p.setTextSize(size); p.setTypeface(Typeface.create("sans",bold?Typeface.BOLD:Typeface.NORMAL));
            text(c,s,x-p.measureText(s)/2,y,size,color,bold);
        }
        void box(Canvas c,float l,float t,float r,float b,float rad,int color) {
            p.setStyle(Paint.Style.FILL); p.setColor(color); c.drawRoundRect(l,t,r,b,rad,rad,p);
        }
        void line(Canvas c,float x1,float y1,float x2,float y2,int color,float sw) {
            p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(sw); p.setColor(color); c.drawLine(x1,y1,x2,y2,p); p.setStyle(Paint.Style.FILL);
        }

        @Override protected void onDraw(Canvas c) {
            int w=getWidth(), h=getHeight();
            p.setShader(new LinearGradient(0,0,0,h,Color.rgb(12,31,24),bg,Shader.TileMode.CLAMP));
            c.drawRect(0,0,w,h,p); p.setShader(null);
            drawSmoke(c,w,h);
            if(tab==0) home(c,w,h);
            if(tab==1) stats(c,w,h);
            if(tab==2) diary(c,w,h);
            if(tab==3) achievements(c,w,h);
            nav(c,w,h);
        }

        void drawSmoke(Canvas c,int w,int h) {
            p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(5);
            p.setColor(Color.argb(30,210,240,225));
            for(int i=0;i<5;i++) {
                Path q=new Path();
                float x=35+i*90;
                q.moveTo(x,h-140);
                q.cubicTo(x-25,h-250,x+45,h-330,x+5,h-450);
                q.cubicTo(x-20,h-510,x+35,h-560,x+15,h-620);
                c.drawPath(q,p);
            }
            p.setStyle(Paint.Style.FILL);
        }

        void header(Canvas c,String title,int w) {
            text(c,title,22,55,27,Color.WHITE,true);
            text(c,"ClearDay",w-105,53,13,green,true);
        }

        void home(Canvas c,int w,int h) {
            text(c,"Siemanko 👋",22,50,28,Color.WHITE,true);
            text(c,"Dbasz o siebie, trzymaj tak! 💪",22,78,14,muted,false);
            text(c,"⚙",w-48,55,27,Color.WHITE,false);

            box(c,14,100,w-14,h-104,28,Color.argb(220,5,19,14));

            long d=days();
            center(c,"Nie palisz już od",w/2,158,17,Color.WHITE,false);
            float radius=Math.min(w*0.29f,112);
            p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(14);
            p.setColor(Color.rgb(21,58,41)); c.drawCircle(w/2,275,radius,p);
            p.setShadowLayer(18,0,0,Color.argb(170,green));
            p.setColor(green); c.drawArc(w/2-radius,275-radius,w/2+radius,275+radius,-90,Math.min(360,d/90f*360f),false,p);
            p.clearShadowLayer(); p.setStyle(Paint.Style.FILL);
            center(c,""+d,w/2,287,58,Color.WHITE,true);
            center(c,"dni",w/2,318,18,Color.WHITE,true);

            center(c,hours()+" godz.   "+minutes()+" min.   "+seconds()+" sek.",w/2,374,14,Color.WHITE,false);
            center(c,"„Lepsze życie zaczyna się od jednej decyzji.”",w/2,410,14,muted,false);

            stat(c,22,435,w/3-29,"€"+String.format(Locale.US,"%.2f",d*(packPrice*perDay/cigarettesPerPack)),"Zaoszczędzone");
            stat(c,w/3+5,435,w/3-29,""+(d*perDay),"Nie wypalone");
            stat(c,2*w/3-12,435,w/3-10,""+d,"Twoja seria");

            box(c,25,545,w-25,605,18,green);
            center(c,"Jestem dumny z siebie! 💪",w/2,583,16,Color.rgb(3,25,13),true);
            center(c,"🔥  Mam ochotę zapalić",w/2,645,17,green,true);
        }

        void stat(Canvas c,float x,float y,float width,String a,String b) {
            box(c,x,y,x+width,y+85,18,Color.rgb(11,35,26));
            center(c,a,x+width/2,y+34,20,green,true);
            center(c,b,x+width/2,y+61,11,muted,false);
        }

        void stats(Canvas c,int w,int h) {
            header(c,"Statystyki",w);
            box(c,15,78,w-15,h-105,24,Color.argb(220,7,24,18));
            String[] filters={"Tydzień","Miesiąc","Rok"};
            for(int i=0;i<3;i++) box(c,28+i*(w-56)/3,96,28+(i+1)*(w-56)/3,138,22,i==1?Color.rgb(37,111,67):Color.rgb(18,39,31));
            for(int i=0;i<3;i++) center(c,filters[i],28+(i+.5f)*(w-56)/3,123,13,Color.WHITE,false);
            stat(c,28,160,(w-66)/2,"€"+String.format(Locale.US,"%.2f",days()*(packPrice*perDay/cigarettesPerPack)),"Zaoszczędzone");
            stat(c,38+(w-66)/2,160,(w-66)/2,""+days()*perDay,"Nie wypalone");
            text(c,"Zaoszczędzone pieniądze",28,300,18,Color.WHITE,true);
            box(c,28,320,w-28,520,20,Color.rgb(8,29,21));
            long dd=Math.max(1,days());
            for(int i=0;i<Math.min(30,(int)dd);i++){
                float bh=30+(i%7)*18;
                float x=40+i*((w-65)/30f);
                box(c,x,495-bh,x+7,495,4,green);
            }
            text(c,"Postęp w czasie",28,555,18,Color.WHITE,true);
            text(c,"Dni bez palenia: "+days(),28,585,14,muted,false);
        }

        void diary(Canvas c,int w,int h) {
            header(c,"Dziennik",w);
            box(c,w-105,25,w-20,65,20,green);
            text(c,"+ Dodaj",w-91,51,14,Color.rgb(3,25,13),true);
            if(diary.size()==0) {
                center(c,"Jeszcze nie ma wpisów.",w/2,220,17,muted,false);
                center(c,"Dodaj pierwszy wpis o swoim dniu.",w/2,250,14,muted,false);
            } else {
                int y=105;
                for(String s:diary) {
                    box(c,18,y,w-18,y+82,18,Color.rgb(10,31,23));
                    text(c,"😊",32,y+35,25,Color.WHITE,false);
                    text(c,s,70,y+32,14,Color.WHITE,true);
                    y+=95;
                }
            }
        }

        void achievements(Canvas c,int w,int h) {
            header(c,"Osiągnięcia",w);
            String[] names={"1 dzień","7 dni","30 dni","€50","Lepszy sen","90 dni","Silniejszy umysł","Więcej czasu"};
            long d=days();
            for(int i=0;i<8;i++) {
                int col=i%2,row=i/2;
                float x=18+col*(w-36)/2f,y=85+row*125;
                box(c,x,y,x+(w-48)/2f,y+105,22,Color.rgb(9,30,22));
                boolean ok=(i==0&&d>=1)||(i==1&&d>=7)||(i==2&&d>=30)||(i==5&&d>=90);
                text(c,ok?"✓":"◇",x+20,y+48,35,ok?green:Color.rgb(100,120,110),true);
                text(c,names[i],x+68,y+39,13,Color.WHITE,true);
                text(c,ok?"Odblokowane":"Zablokowane",x+68,y+64,11,ok?green:muted,false);
            }
        }

        void nav(Canvas c,int w,int h) {
            box(c,0,h-78,w,h,0,Color.rgb(3,13,9));
            String[] names={"Start","Statystyki","Dziennik","Osiągnięcia"};
            String[] icons={"⌂","▥","▤","♕"};
            for(int i=0;i<4;i++) {
                float x=w*(i+.5f)/4;
                center(c,icons[i],x,h-45,22,i==tab?green:muted,true);
                center(c,names[i],x,h-18,10,i==tab?green:muted,true);
            }
        }

        @Override public boolean onTouchEvent(MotionEvent e) {
            if(e.getAction()!=MotionEvent.ACTION_UP) return true;
            float x=e.getX(), y=e.getY(); int w=getWidth(),h=getHeight();
            if(y>h-90){ tab=Math.min(3,Math.max(0,(int)(x/(w/4)))); invalidate(); return true; }
            if(tab==0 && y>610 && y<690) craving();
            else if(tab==0 && y<85 && x>w-85) settings();
            else if(tab==2 && y<90 && x>w-130) addDiary();
            return true;
        }

        void craving() {
            final String[] tips={"Ćwiczenie oddechowe","Szybki trening (5 minut)","Muzyka motywacyjna","Przypomnij mi dlaczego rzucam","Napisz w dzienniku"};
            new AlertDialog.Builder(MainActivity.this)
                .setTitle("Mam ochotę zapalić")
                .setMessage("To tylko chwilowa ochota. Zrób jedną z poniższych rzeczy i przeczekaj kilka minut.")
                .setItems(tips,(d,which)-> Toast.makeText(MainActivity.this,tips[which]+" 💚",Toast.LENGTH_SHORT).show())
                .setNegativeButton("Zamknij",null).show();
        }

        void addDiary() {
            final EditText e=new EditText(MainActivity.this);
            e.setHint("Jak się dziś czujesz?");
            new AlertDialog.Builder(MainActivity.this).setTitle("Dodaj wpis").setView(e)
                .setPositiveButton("Dodaj",(d,w)->{ if(e.getText().length()>0){ diary.add(0,e.getText().toString()); invalidate(); }})
                .setNegativeButton("Anuluj",null).show();
        }

        void settings() {
            LinearLayout l=new LinearLayout(MainActivity.this);
            l.setOrientation(LinearLayout.VERTICAL); l.setPadding(35,10,35,0);
            EditText p=new EditText(MainActivity.this); p.setHint("Cena paczki (€)"); p.setText(""+packPrice); p.setInputType(2|8192);
            EditText c=new EditText(MainActivity.this); c.setHint("Papierosy dziennie"); c.setText(""+perDay); c.setInputType(2);
            EditText s=new EditText(MainActivity.this); s.setHint("Papierosów w paczce"); s.setText(""+cigarettesPerPack); s.setInputType(2);
            Button reset=new Button(MainActivity.this); reset.setText("Ustaw start od teraz");
            l.addView(p);l.addView(c);l.addView(s);l.addView(reset);
            AlertDialog dlg=new AlertDialog.Builder(MainActivity.this).setTitle("Ustawienia").setView(l)
                .setPositiveButton("Zapisz",(d,w)->{
                    try{packPrice=Float.parseFloat(p.getText().toString());perDay=Integer.parseInt(c.getText().toString());cigarettesPerPack=Integer.parseInt(s.getText().toString());}catch(Exception ignored){}
                    getSharedPreferences("data",0).edit().putFloat("price",packPrice).putInt("perDay",perDay).putInt("pack",cigarettesPerPack).apply();
                    invalidate();
                }).setNegativeButton("Anuluj",null).create();
            reset.setOnClickListener(x->{start=System.currentTimeMillis();getSharedPreferences("data",0).edit().putLong("start",start).apply();dlg.dismiss();invalidate();});
            dlg.show();
        }
    }
}
