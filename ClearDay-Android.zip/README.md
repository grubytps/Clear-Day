# ClearDay

Android app in Polish, styled like the provided dark green ClearDay mockup.

Features:
- quit timer with days/hours/minutes/seconds
- money saved and cigarettes not smoked
- statistics
- diary
- achievements
- craving-help screen
- settings saved locally on the phone
- GitHub Actions workflow that builds `app-debug.apk`

Build: GitHub Actions -> Build ClearDay APK -> download artifact `ClearDay-debug-apk`.
